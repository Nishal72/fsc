# Carousel with HTML, CSS, JAVASCRIPT
### **My Personal Project to make Carousel**
#### This Project Uses Language
- HTML
- CSS
- JAVASCRIPT
<p>I'm make it with <b>CSS Preprocessor</b>
But i'm just use <b>Vanilla Javascript</b> for interactive surely and the website is still too heavy.</p>

***Thank you for your attention.***
