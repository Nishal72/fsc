function startgame_click(){
    document.getElementById("myButton").onclick = function () {
        console.log("yes");
        location.href = "index1.html";
    };
}

